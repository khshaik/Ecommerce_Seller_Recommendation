import time

# --- 1. Define Table Name and Path ---
table_name = "hudi_test_table"
table_path = "/opt/spark-data/" + table_name
print(f"--- Hudi test started. Table path will be: {table_path} ---")

# --- 2. Create Initial Sample Data ---
data = [
    (1, "Alice", 1000, "USA", "2025-01-01 10:00:00"),
    (2, "Bob", 1500, "Europe", "2025-01-01 10:01:00"),
    (3, "Charlie", 2000, "USA", "2025-01-01 10:02:00")
]
columns = ["user_id", "name", "revenue", "region", "last_updated_ts"]
initial_df = spark.createDataFrame(data, columns)
print("\n--- Initial data to be written (3 records): ---")
initial_df.show()

# --- 3. Define Hudi Write Options ---
hudi_options = {
    'hoodie.table.name': table_name,
    'hoodie.datasource.write.recordkey.field': 'user_id',
    'hoodie.datasource.write.precombine.field': 'last_updated_ts',
    'hoodie.datasource.write.partitionpath.field': 'region',
    'hoodie.datasource.write.table.type': 'COPY_ON_WRITE',
    'hoodie.datasource.write.operation': 'upsert',
    'hoodie.datasource.write.hive_style_partitioning': 'true'
}

# --- 4. Write the Initial Data (Overwrite) ---
print("\n--- Writing initial data... ---")
# This command will now succeed
initial_df.write.format("hudi") \
    .options(**hudi_options) \
    .mode("Overwrite") \
    .save(table_path)
print("--- Initial write complete. ---")

# --- 5. Read and View the Hudi Table (V1) ---
print("\n--- Reading Hudi table after initial write (should show 3 records): ---")
# This will now find the file
hudi_df_v1 = spark.read.format("hudi").load(table_path)
hudi_df_v1.show()

# --- 6. Create Updated Data (UPSERT) ---
update_data = [
    (1, "Alice", 1200, "USA", "2025-01-02 11:00:00"),  # UPDATE
    (4, "David", 3000, "Asia", "2025-01-02 11:01:00")   # INSERT
]
update_df = spark.createDataFrame(update_data, columns)
print("\n--- Data for UPSERT (2 records): ---")
update_df.show()

# --- 7. Write the Updated Data (Append) ---
print("\n--- Performing upsert... ---")
# This command will also succeed
update_df.write.format("hudi") \
    .options(**hudi_options) \
    .mode("Append") \
    .save(table_path)
print("--- Upsert complete. ---")

# --- 8. Clear Cache (Still good practice) ---
print("\n--- Clearing Spark's catalog cache... ---")
spark.catalog.clearCache()
print("--- Cache cleared. ---")

# --- 9. Read and View the Final Hudi Table (V2) ---
print("\n--- Reading Hudi table after upsert (should show 4 records): ---")
final_df = spark.read.format("hudi").load(table_path)

# --- 10. Verify with Spark SQL ---
print("\n--- Registering final table as 'hudi_table' and querying: ---")
final_df.createOrReplaceTempView("hudi_table")

# This will now work
spark.sql("SELECT * FROM hudi_table ORDER BY user_id").show()

print("\n--- Final 'show tables' output: ---")
spark.sql("show tables").show()

print("\n--- Hudi Test Complete! ---")