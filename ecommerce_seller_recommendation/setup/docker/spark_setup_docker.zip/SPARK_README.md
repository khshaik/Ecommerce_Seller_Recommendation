# Steps for configuring spark

1. Unzip and extract all files at one place

2. Run the following command

`docker compose up --build`

You should see successful output something like this:

[+] Running 4/4
 ✔ ecomm-spark                                       Built                                                                  0.0s 
 ✔ Container ecomm_recommendations-spark-master-1    Running                                                                0.0s 
 ✔ Container ecomm_recommendations-spark-worker-b-1  Running                                                                0.0s 
 ✔ Container ecomm_recommendations-spark-worker-a-1  Running   

3. Go to this url in browser to verify if spark-master is running fine
http://localhost:9090

4. Now run the pyspark shell in the same directory where you have all files unzipped
`docker compose exec spark-master /opt/spark/bin/pyspark --master spark://spark-master:7077`

In the logs you should see something like this:

The jars for the packages stored in: /root/.ivy2/jars
org.apache.hudi#hudi-spark3.4-bundle_2.12 added as a dependency
:: resolving dependencies :: org.apache.spark#spark-submit-parent-d8015a16-1238-4f1d-b0da-d85c83db9303;1.0
	confs: [default]
	found org.apache.hudi#hudi-spark3.4-bundle_2.12;0.15.0 in central
downloading https://repo1.maven.org/maven2/org/apache/hudi/hudi-spark3.4-bundle_2.12/0.15.0/hudi-spark3.4-bundle_2.12-0.15.0.jar ...
	[SUCCESSFUL ] org.apache.hudi#hudi-spark3.4-bundle_2.12;0.15.0!hudi-spark3.4-bundle_2.12.jar (36995ms)
:: resolution report :: resolve 1674ms :: artifacts dl 37000ms
	:: modules in use:
	org.apache.hudi#hudi-spark3.4-bundle_2.12;0.15.0 from central in [default]
	---------------------------------------------------------------------
	|                  |            modules            ||   artifacts   |
	|       conf       | number| search|dwnlded|evicted|| number|dwnlded|
	---------------------------------------------------------------------
	|      default     |   1   |   1   |   1   |   0   ||   1   |   1   |
	---------------------------------------------------------------------
:: retrieving :: org.apache.spark#spark-submit-parent-d8015a16-1238-4f1d-b0da-d85c83db9303
	confs: [default]
	1 artifacts copied, 0 already retrieved (106405kB/66ms)
25/11/12 16:32:19 WARN NativeCodeLoader: Unable to load native-hadoop library for your platform... using builtin-java classes where applicable
Setting default log level to "WARN".
To adjust logging level use sc.setLogLevel(newLevel). For SparkR, use setLogLevel(newLevel).
Welcome to
      ____              __
     / __/__  ___ _____/ /__
    _\ \/ _ \/ _ `/ __/  '_/
   /__ / .__/\_,_/_/ /_/\_\   version 3.4.0
      /_/

Using Python version 3.10.6 (main, Mar 10 2023 10:55:28)
Spark context Web UI available at http://9731c6229706:4040
Spark context available as 'sc' (master = spark://spark-master:7077, app id = app-20251112163220-0000).
SparkSession available as 'spark'.
>>> 

5. Now copy the contents of the hudi test script: hudi-test.py and paste it in the prompt in the pyspark shell

You should see the final output as something like this:

>>> # This will now work
>>> spark.sql("SELECT * FROM hudi_table ORDER BY user_id").show()
+-------------------+--------------------+------------------+----------------------+--------------------+-------+-------+-------+-------------------+------+
|_hoodie_commit_time|_hoodie_commit_seqno|_hoodie_record_key|_hoodie_partition_path|   _hoodie_file_name|user_id|   name|revenue|    last_updated_ts|region|
+-------------------+--------------------+------------------+----------------------+--------------------+-------+-------+-------+-------------------+------+
|  20251112163238643|20251112163238643...|                 1|            region=USA|debcde3f-5931-49d...|      1|  Alice|   1200|2025-01-02 11:00:00|   USA|
|  20251112163232411|20251112163232411...|                 2|         region=Europe|28d3f41b-e141-4c4...|      2|    Bob|   1500|2025-01-01 10:01:00|Europe|
|  20251112163232411|20251112163232411...|                 3|            region=USA|debcde3f-5931-49d...|      3|Charlie|   2000|2025-01-01 10:02:00|   USA|
|  20251112163238643|20251112163238643...|                 4|           region=Asia|0cacc151-802f-416...|      4|  David|   3000|2025-01-02 11:01:00|  Asia|
+-------------------+--------------------+------------------+----------------------+--------------------+-------+-------+-------+-------------------+------+

>>> 
>>> print("\n--- Final 'show tables' output: ---")

--- Final 'show tables' output: ---
>>> spark.sql("show tables").show()
25/11/12 16:32:41 WARN ObjectStore: Failed to get database global_temp, returning NoSuchObjectException
+---------+----------+-----------+
|namespace| tableName|isTemporary|
+---------+----------+-----------+
|         |hudi_table|       true|
+---------+----------+-----------+


If you're seeing the above tables, then all your installation is successful